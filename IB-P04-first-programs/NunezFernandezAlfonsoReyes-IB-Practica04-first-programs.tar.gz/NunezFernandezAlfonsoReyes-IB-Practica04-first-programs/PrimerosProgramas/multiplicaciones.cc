#include <iostream>
using namespace std;
int main() {
	double a, b;
	cout << "Introduce un valor: "; 
	cin >> a;
	cout << "Introduce otro valor: ";
	cin >> b;
	cout << "El resultado es " << a * b << endl;
}
