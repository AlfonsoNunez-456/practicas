#include <iostream>
using namespace std;
int main() {
	cout << 7283 + 1296 << endl;
}
