#include <iostream>
using namespace std;
int main() {
	string nombre;
	string edad;
	cout << "Tu nombre? ";
	cin >> nombre;
	cout << "Tu edad? ";
	cin >> edad;
	cout << "Hola, eres " << nombre << " y tines " << edad << " años." << endl;
}
