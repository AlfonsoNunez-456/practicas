#include <iostream>
using namespace std;
int main() {
	string nombre; // 1 //
	cout << "Tu nombre? ";
	cin >> nombre; //2//
	cout << "Muy buenas, " << nombre << ", eres un gran programador." << endl; //3//
}

